#include <DxLib.h>
#include "../Common/Transform.h"
#include "../../Engine/Component/Mesh.h"
#include "../../Engine/Scene/SceneManager.h"
#include "../GameObject/GameObject.h"
#include "Animator.h"

Animator::Animator(GameObject& gameObject, const Mesh& mesh)
    :
	Component(gameObject),
    mesh_(mesh),
    playType_(-1),
    playAnim_(),
    isLoop_(true),
    prevType_(-1),
    prevAnim_(),
    blendRate_(1.0f),
    blendTime_(0.2f)  // デフォルト0.2秒でブレンド
{
}

Animator::~Animator(void)
{
}

void Animator::Add(int type, float speed, int animHandle)
{
    Animation animation;
    animation.model = animHandle;
    animation.animIndex = -1;
    Add(type, speed, animation);
}

void Animator::AddFromSelf(int type, float speed, int animIndex)
{
    Animation animation;
    animation.model = -1;
    animation.animIndex = animIndex;
    Add(type, speed, animation);
}

void Animator::Play(int type, bool isLoop)
{
    if (playType_ == type) { return; }

    // 前のアニメーションをブレンド用に保存
    if (playType_ != -1)
    {
        // 既にブレンド中なら前のブレンド先をデタッチ
        if (prevType_ != -1 && prevAnim_.attachNo != -1)
        {
            MV1DetachAnim(mesh_.GetHandle(), prevAnim_.attachNo);
        }
        prevAnim_ = playAnim_;
        prevType_ = playType_;
        blendRate_ = 0.0f;  // ブレンド開始
    }
    else
    {
        blendRate_ = 1.0f;  // 最初の再生はブレンドなし
    }

    // 新しいアニメーションをセット
    playType_ = type;
    playAnim_ = animations_[type];
    playAnim_.step = 0.0f;
    isLoop_ = isLoop;

    // スピード
    playAnim_.speed = animations_[type].speed;

    Attach(playAnim_);
    playAnim_.totalTime = MV1GetAttachAnimTotalTime(mesh_.GetHandle(), playAnim_.attachNo);

    // ブレンドウェイト初期設定
    if (prevType_ != -1)
    {
        MV1SetAttachAnimBlendRate(mesh_.GetHandle(), prevAnim_.attachNo, 1.0f - blendRate_);
        MV1SetAttachAnimBlendRate(mesh_.GetHandle(), playAnim_.attachNo, blendRate_);
    }
}

void Animator::Replay(void)
{
    playAnim_.step = 0.0f;
}

void Animator::Update(void)
{
    if (playType_ == -1) { return; }

    const float deltaTime = SceneManager::GetInstance().GetDeltaTime();

    // ブレンド更新
    if (blendRate_ < 1.0f && prevType_ != -1)
    {
        blendRate_ += deltaTime / blendTime_;
        if (blendRate_ >= 1.0f)
        {
            blendRate_ = 1.0f;
            // ブレンド完了：前のアニメーションをデタッチ
            if (prevAnim_.attachNo != -1)
            {
                MV1DetachAnim(mesh_.GetHandle(), prevAnim_.attachNo);
                prevAnim_.attachNo = -1;
            }
            prevType_ = -1;
        }

        MV1SetAttachAnimBlendRate(mesh_.GetHandle(), prevAnim_.attachNo, 1.0f - blendRate_);
        MV1SetAttachAnimBlendRate(mesh_.GetHandle(), playAnim_.attachNo, blendRate_);

        // 前アニメのステップ更新
        if (prevAnim_.attachNo != -1)
        {
            prevAnim_.step += deltaTime * prevAnim_.speed;
            if (prevAnim_.step > prevAnim_.totalTime) { prevAnim_.step = 0.0f; }
            MV1SetAttachAnimTime(mesh_.GetHandle(), prevAnim_.attachNo, prevAnim_.step);
        }
    }

    // 現在のアニメーション更新
    playAnim_.step += deltaTime * playAnim_.speed;

    if (playAnim_.step > playAnim_.totalTime)
    {
        if (isLoop_) { playAnim_.step = 0.0f; }
        else { playAnim_.step = playAnim_.totalTime; }
    }

    MV1SetAttachAnimTime(mesh_.GetHandle(), playAnim_.attachNo, playAnim_.step);
}

void Animator::Release(void)
{
    animations_.clear();
}

int Animator::GetPlayType(void) const
{
    return playType_;
}

bool Animator::IsEnd(void) const
{
    if (isLoop_) return false;
    return playAnim_.step >= playAnim_.totalTime;
}

const Animator::Animation& Animator::GetPlayAnim(void) const
{
    return playAnim_;
}

bool Animator::IsBlending(void) const
{
    return blendRate_ < 1.0f;
}

void Animator::Add(int type, float speed, Animation& animation)
{
    animation.speed = speed;
    if (animations_.count(type) == 0)
    {
        animations_.emplace(type, animation);
    }
}

void Animator::Attach(Animation& anim)
{
    if (anim.model == -1)
    {
        anim.attachNo = MV1AttachAnim(mesh_.GetHandle(), anim.animIndex);
    }
    else
    {
        anim.attachNo = MV1AttachAnim(mesh_.GetHandle(), 0, anim.model);
    }
}