#pragma once
#include <vector>
#include <memory>
#include <type_traits>
#include <utility>
#include "../Common/Transform.h"
#include "../Component/Component.h"

class ResourceManager;
class SceneManager;

class GameObject
{

public:

	// コンストラクタ
	GameObject();

	// デストラクタ
	virtual ~GameObject();

	// リソースロード
	virtual void Load() = 0;

	// 初期化
	void Init(void);

	// 更新
	virtual void Update();

	// 描画
	virtual void Draw();

	// 解放
	virtual void Release();

	// コンポーネントを追加する
	template <class T, class... Args>
	T* AddComponent(Args&&... args)
	{
		static_assert(std::is_base_of_v<Component, T>, "T は Component を継承している必要があります");

		auto component = std::make_unique<T>(*this, std::forward<Args>(args)...);
		T* ret = component.get();
		components_.emplace_back(std::move(component));
		return ret;
	}

	// コンポーネントを取得する
	template <class T>
	T* GetComponent(void)
	{
		static_assert(std::is_base_of_v<Component, T>, "T は Component を継承している必要があります");

		for (auto& component : components_)
		{
			if (T* ret = dynamic_cast<T*>(component.get()))
			{
				return ret;
			}
		}
		return nullptr;
	}


	// 大きさ、回転、座標等の取得
	const Transform& GetTransform() const;
	Transform& GetTransform();

protected:

	// シングルトン参照
	ResourceManager& resMng_;
	SceneManager& scnMng_;

	// モデル制御の基本情報
	Transform transform_;

	// 所有しているコンポーネント
	std::vector<std::unique_ptr<Component>> components_;

	// 大きさ、回転、座標の初期化
	virtual void InitTransform() = 0;

	// 描画設定の初期化
	virtual void InitRenderer() = 0;

	// アニメーションの初期化
	virtual void InitAnimation() = 0;

	// 初期化後の個別処理
	virtual void InitPost() = 0;
};
