#pragma once

// デバッグ機能を使うかどうか
#ifdef _DEBUG
#define USE_DEBUG_TOOLS 1
#else
#define USE_DEBUG_TOOLS 0
#endif