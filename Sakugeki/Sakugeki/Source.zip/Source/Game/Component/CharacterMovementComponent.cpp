#include <algorithm>
#include "../../Engine/Common/Transform.h"
#include "../../Engine/Math/Quaternion.h"
#include "../../Engine/Scene/SceneManager.h"
#include "../Collider/ColliderBase.h"
#include "../Collider/ColliderCapsule.h"
#include "../Collider/ColliderCircleBoundary.h"
#include "../Collider/ColliderModel.h"
#include "../Collider/ColliderPlane.h"
#include "CharacterMovementComponent.h"

CharacterMovementComponent::CharacterMovementComponent(Transform& transform,
	const std::vector<const ColliderBase*>& hitColliders)
	:
	transform_(transform),
	hitColliders_(hitColliders),
	capsule_(nullptr),
	maxWalkSpeed_(0.0f),
	jumpSpeed_(0.0f),
	velocity_(Vector3::ZERO),
	moveInput_(Vector3::ZERO),
	facingDir_(Vector3::ZERO),
	isJumpRequested_(false),
	isGrounded_(false)
{
}

CharacterMovementComponent::~CharacterMovementComponent(void)
{
}

void CharacterMovementComponent::Update(void)
{
	const float deltaTime = SceneManager::GetInstance().GetDeltaTime();

	// ���������̑��x�i���͂����̂܂ܑ��x�ɂ���j
	Vector3 input(moveInput_.x, 0.0f, moveInput_.z);
	if (input.SquareMagnitude() > 1.0f) { input = input.Normalized(); }
	velocity_.x = input.x * maxWalkSpeed_;
	velocity_.z = input.z * maxWalkSpeed_;

	// ���͂�����΁A���̕���������
	if (!input.IsZero()) { facingDir_ = input.Normalized(); }

	// �W�����v�i�ڒn���Ă���Ƃ������j
	if (isJumpRequested_ && isGrounded_)
	{
		velocity_.y = jumpSpeed_;
		isGrounded_ = false;
	}

	// �ړ������֌�������
	RotateToFacing();

	// �d��
	ApplyGravity(deltaTime);

	// ���������̈ړ��ƏՓ�
	transform_.pos += Vector3(velocity_.x, 0.0f, velocity_.z) * deltaTime;
	CollideBoundary();
	CollideModel();

	// ���������̈ړ��Ɛڒn
	transform_.pos += Vector3(0.0f, velocity_.y, 0.0f) * deltaTime;
	CollideGround();

	// �w���͂��̃t���[���ŏ����
	moveInput_ = Vector3::ZERO;
	isJumpRequested_ = false;
}

void CharacterMovementComponent::AddMoveInput(const Vector3& worldDir)
{
	moveInput_ += worldDir;
}

void CharacterMovementComponent::Jump(void)
{
	isJumpRequested_ = true;
}

void CharacterMovementComponent::SetCapsule(const ColliderCapsule* capsule)
{
	capsule_ = capsule;
}

void CharacterMovementComponent::SetMaxWalkSpeed(float speed)
{
	maxWalkSpeed_ = speed;
}

void CharacterMovementComponent::SetJumpSpeed(float speed)
{
	jumpSpeed_ = speed;
}

const Vector3& CharacterMovementComponent::GetVelocity(void) const
{
	return velocity_;
}

bool CharacterMovementComponent::IsGrounded(void) const
{
	return isGrounded_;
}

bool CharacterMovementComponent::IsMoving(void) const
{
	return !Vector3(velocity_.x, 0.0f, velocity_.z).IsZero();
}

void CharacterMovementComponent::RotateToFacing(void)
{
	if (facingDir_.IsZero()) { return; }

	// �ړ����������]�ɕϊ�����
	Quaternion goalRot = Quaternion::LookRotation(facingDir_);

	// ��]�̕��
	transform_.quaRot = Quaternion::Slerp(transform_.quaRot, goalRot, ROTATE_RATE);
}

void CharacterMovementComponent::ApplyGravity(float deltaTime)
{
	velocity_.y -= GRAVITY * deltaTime;

	// �������x�̏��
	velocity_.y = (std::max)(velocity_.y, -FALL_SPEED_MAX);
}

void CharacterMovementComponent::CollideBoundary(void)
{
	// �����̑̂̔��a
	float bodyRadius = (capsule_ != nullptr) ? capsule_->GetRadius() : 0.0f;

	for (const ColliderBase* hitCol : hitColliders_)
	{
		if (hitCol->GetShape() != ColliderBase::SHAPE::CIRCLE_BOUNDARY) continue;

		const auto* boundary = static_cast<const ColliderCircleBoundary*>(hitCol);
		boundary->PushBackInside(transform_.pos, bodyRadius);
	}
}

void CharacterMovementComponent::CollideModel(void)
{
	if (capsule_ == nullptr) { return; }

	for (const ColliderBase* hitCol : hitColliders_)
	{
		if (hitCol->GetShape() != ColliderBase::SHAPE::MODEL) continue;

		const auto* model = static_cast<const ColliderModel*>(hitCol);

		// �w�肳�ꂽ�񐔂Ƌ����ŎO�p�`�̖@�������ɉ����߂�
		capsule_->PushBackAlongNormal(
			model, transform_,
			CNT_TRY_COLLISION, DIS_COLLISION_BACK,
			true,	// �u���b�N���X�g�g�p����
			false	// �z���C�g���X�g�g�p����
		);
	}
}

void CharacterMovementComponent::CollideGround(void)
{
	isGrounded_ = false;

	// �㏸���͔��肵�Ȃ�
	if (velocity_.y > 0.0f) { return; }

	for (const ColliderBase* hitCol : hitColliders_)
	{
		if (hitCol->GetShape() != ColliderBase::SHAPE::PLANE) continue;

		const auto* plane = static_cast<const ColliderPlane*>(hitCol);
		float height = plane->GetHeight();

		if (transform_.pos.y <= height)
		{
			transform_.pos.y = height;
			velocity_.y = 0.0f;
			isGrounded_ = true;
		}
	}
}
