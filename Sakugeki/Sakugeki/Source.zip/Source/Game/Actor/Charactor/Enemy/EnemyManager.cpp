#include <string>
#include <fstream>
#include "../../../../Engine/Core/Application.h"
#include "../../../../Engine/Resource/ResourcePath.h"
#include "../../../../Engine/Utility/AsoUtility.h"
#include "EnemyManager.h"

EnemyManager::EnemyManager(Player* player)
	:
	player_(player)
{
}

EnemyManager::~EnemyManager(void)
{
}

void EnemyManager::Init(void)
{
	// エネミーのデータ読み込み
	LoadCsvData();
}

// 更新
void EnemyManager::Update(void)
{
	for (auto& enemy : enemies_)
	{
		enemy->Update();
	}
}

// 描画
void EnemyManager::Draw(void)
{
	for (auto& enemy : enemies_)
	{
		enemy->Draw();
	}
}

// 解放
void EnemyManager::Release(void)
{
	for (auto& enemy : enemies_)
	{
		enemy->Release();
		delete enemy;
	}
}

void EnemyManager::LoadCsvData(void)
{
	// ファイルの読み込み
	std::ifstream ifs = std::ifstream(ResourcePath::PATH_CSV + L"EnemyData.csv");
	// エラーが発生
	if (!ifs) return;

	// ファイルを1行ずつ読み込む
	std::string line; // 1行の文字情報
	std::vector<std::string> strSplit; // 1行を1文字の動的配列に分割

	bool isHeader = true;

	while (getline(ifs, line))
	{
		if (isHeader)
		{
			isHeader = false;
			continue;
		}

		// １行をカンマ区切りで分割
		strSplit = AsoUtility::Split(line, ',');

		Enemy* enemy = nullptr;

		// 構造体に合わせて読み込みデータを格納
		Enemy::EnemyData data = Enemy::EnemyData();
		int idx = 0;
		// ID
		data.id = stoi(strSplit[idx++]);
		// 種別
		data.type = static_cast<Enemy::TYPE>(stoi(strSplit[idx++]));
		// HPGauge
		data.hp = stoi(strSplit[idx++]);
		// 初期座標
		data.defaultPos =
		{
			stof(strSplit[idx++]),
			stof(strSplit[idx++]),
			stof(strSplit[idx++]),
		};
		// エネミー生成
		Create(data);
	}
	
	ifs.close();
}

Enemy* EnemyManager::Create(const Enemy::EnemyData& data)
{
	Enemy* enemy = nullptr;

	// 種別事に敵を生成
	switch (data.type)
	{

	}

	if (enemy != nullptr)
	{
		enemy->Init(); // 初期化
		enemies_.emplace_back(enemy); // 敵リストに追加
	}

	return enemy;
}