#pragma once
#include "../Actor.h"

// �n�ʁi���ʃR���C�_�j
class StageGround : public Actor
{
public:

	enum class COLLIDER_TYPE
	{
		PLANE,
		BOUNDARY,
		MAX
	};

	StageGround(void);
	~StageGround(void) override;

	void Load(void) override;
	void Update(void) override;

protected:

	void InitTransform(void) override;
	void InitRenderer(void) override;
	void InitCollider(void) override;
	void InitAnimation(void) override {}
	void InitPost(void) override {}

private:

	// �ړ��\�Ȕ��a
	static constexpr float BOUNDARY_RADIUS = 2800.0f;
};