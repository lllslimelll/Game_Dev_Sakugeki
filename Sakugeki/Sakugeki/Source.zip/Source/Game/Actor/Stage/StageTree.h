#pragma once
#include "../Actor.h"

// �؁i���͑S���̖؂�1�̃��f���Ƃ��Ĉꊇ���[�h�j
class StageTree : public Actor
{
public:

	enum class COLLIDER_TYPE
	{
		MAX
	};

	StageTree(void);
	~StageTree(void) override;

	void Load(void) override;
	void Update(void) override;

protected:

	void InitTransform(void) override;
	void InitRenderer(void) override;
	void InitCollider(void) override;
	void InitAnimation(void) override {}
	void InitPost(void) override {}
};